#!/usr/bin/env bash
python proxyPool.py server &
python proxyPool.py schedule